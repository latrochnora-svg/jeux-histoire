# Ötzi – Chasse au bison

Jeu pédagogique en HTML5 créé pour les élèves de Mme Latroch dans le cadre de cours d'histoire.

## Objectif
Incarner Ötzi, l’homme des glaces, et marquer des bisons avec des javelots pour nourrir le clan.

## Commandes
- **Flèches directionnelles** ou **WASD** : se déplacer  
- **Espace** : lancer un javelot  
- **P** : mettre en pause

---
Créé avec ❤️ pour l'apprentissage ludique de la préhistoire.
